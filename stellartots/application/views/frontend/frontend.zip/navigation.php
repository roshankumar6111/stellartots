 <nav id="main-menu">
                    	<div class="dt-menu-toggle" id="dt-menu-toggle">Menu<span class="dt-menu-toggle-icon"></span></div>
                        <ul id="menu-main-menu" class="menu">
                             <li class="current_page_item mustard"> <a href="<?php echo base_url();?>">Home</a> </li>
                            <li class=" menu-item-simple-parent menu-item-depth-0 red"> <a href="<?php echo base_url();?>index.php?Landing/about"> About Us </a> 

                                <a class="dt-menu-expand">+</a>                      
                            </li>
                           
                            <li class=" menu-item-simple-parent menu-item-depth-0 green"> <a href="our-staffs.html"> Our Organisation </a>
                                 <ul class="sub-menu">
                                    <li> <a href="<?php echo base_url();?>index.php?Landing/curve"> Stellar tots learning curve </a> </li>
                                    <li> <a href="<?php echo base_url();?>index.php?Landing/facilities"> Facilities </a>  </li>
                                    <li> <a href="<?php echo base_url();?>index.php?Landing/activity"> Activities </a> </li>
                                    <li> <a href="<?php echo base_url();?>index.php?Landing/mentors"> Mentors </a> </li>
<!--
                                    <li> <a href="#"> Infrastructure </a> 
                                    <li> <a href="#"> Methodology </a> 
                                    <li> <a href="#"> Extra Curriculars </a> 
                                    <li> <a href="#"> Building Futures</a> 
                                        <a class="dt-menu-expand">+</a>                             
                                    </li>
-->
                                </ul> 
                            </li>  
                            <li class=" menu-item-simple-parent menu-item-depth-0 yellow"> <a href="our-staffs.html"> Admissions </a>
                                 <ul class="sub-menu">
                                    <li> <a href="#"> Admission Process </a> </li>
                                    <li> <a href="#"> General Know How </a>  </li> 
                                        <a class="dt-menu-expand">+</a>                             
                                  
                                </ul> 
                            </li>
                            <li class="menu-item-simple-parent menu-item-depth-0 pink"> <a href="our-staffs.html"> Career </a>
                                 <ul class="sub-menu">
                                    <li> <a href="#"> Vacancies </a> </li>
                                    <li> <a href="#"> Apply for a job </a>  </li> 
                                        <a class="dt-menu-expand">+</a>                             
                                  
                                </ul> 
                            </li>
                            <li class="pink"><a href="<?php base_url();?>index.php?Landing/contact" title="">Contact us</a></li>
                             <li class="purple"><a href="shop.html" title="">Photo Gallery</a></li>
                            <li class="yellow"><a href="<?php base_url();?>index.php?Login" class="link" title="">Login</a></li>

                        </ul>
                    </nav>