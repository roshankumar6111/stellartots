 <footer>
            <!--footer-widgets-wrapper starts-->
            <div class="footer-widgets-wrapper">
              
                <div class="container">
                    

                    <div class="column dt-sc-one-fourth">
                        <aside class="widget tweetbox">
                            <h3 class="widgettitle yellow_sketch"><a href="#"> Twitter Feeds </a></h3>
                            <div id="tweets_container"></div>
                        </aside>
                    </div>
                    <div class="column dt-sc-one-fourth">
                        <aside class="widget widget_text">
                        <h3 class="widgettitle steelblue_sketch">Contact</h3>
                            <div class="textwidget">
                                <p class="dt-sc-contact-info"><span class="fa fa-map-marker"></span> 986/E Main 100 Foota Road, Near Maujpur Chowk an Babarpur Bus Terminal Delhi 110032<br>Phone - 8860023592  </p>
                                <p class="dt-sc-contact-info"><span class="fa fa-phone"></span> +91-8860023592  </p>
                                <p class="dt-sc-contact-info"><span class="fa fa-envelope"></span><a href="mailto:yourname@somemail.com"> stellartots@gmail.com</a></p>
                            </div>
                        </aside>
<!--
                        <aside class="widget mailchimp">
                            <p> We're social </p>
                            <form name="frmnewsletter" class="mailchimp-form" action="php/subscribe.php" method="post">
                                <p>
                                    <span class="fa fa-envelope-o"> </span>
                                    <input type="email" placeholder="Email Address" name="mc_email" required />	
                                </p>	
                                <input type="submit" value="Subscribe" class="button" name="btnsubscribe">
                            </form>
                            <div id="ajax_subscribe_msg"></div>
                        </aside>
-->
                    </div>
                    
                </div>    
                <!--container ends-->
            </div>
            <!--footer-widgets-wrapper ends-->  
            <div class="copyright">
        		<div class="container">
                	<p class="copyright-info">@ stellartotos. All rights reserved.</p>
        			<div class="footer-links">
                        <p>Follow us</p>
                        <ul class="dt-sc-social-icons">
                        	<li class="facebook"><a href="#"><img src="<?php base_url();?>assets/images/facebook.png" alt="" title=""></a></li>
                            <li class="twitter"><a href="#"><img src="<?php base_url();?>assets/images/twitter.png" alt="" title=""></a></li>
                            <li class="gplus"><a href="#"><img src="<?php base_url();?>assets/images/gplus.png" alt="" title=""></a></li>
                            <li class="pinterest"><a href="#"><img src="<?php base_url();?>assets/images/pinterest.png" alt="" title=""></a></li>
                        </ul>
                    </div>
        		</div>
        	</div>  
        </footer>