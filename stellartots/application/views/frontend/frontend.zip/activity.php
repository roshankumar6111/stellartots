  <div class="container">
                        <!--dt-sc-one-half starts-->
                            <h2>Activities</h2>
                            <!--dt-sc-one-half starts-->

                                
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span> > </span> 
                                    </div>
                                    
                                    <h4 style="color:white;">In addition to a thoroughly English Speaking and creatively strong environment,  we host a variety of activities for our young stellarities to make learning fun. Our comprehensive curriculum enables learning through interactive games, story telling, puppet shows, movie screening, and art and craft. We understand the importance of extra curricular and also have personality development and public speaking activities for our students.<br>In addition to these, we have school picnics, birthday celebrations, festival celebrations and in-house interactive functions hosted for our students and parents.</h4>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>

                                <div class="dt-sc-hr-very-small"></div>

                            
               <!--dt-sc-one-half ends-->
                        
                  
                    </div>