  <div class="container">
                        <!--dt-sc-one-half starts-->
                            <h2>Stellar tots learning curve</h2>
                            <!--dt-sc-one-half starts-->

                                
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span> > </span> 
                                    </div>
                                    
                                    <h4 style="color:white;">Stellar Tots Preschool has a holistically designed curriculum that caters to all parts of a young child’s personality. With the help of a variety of teaching aids such as concept based puzzles, audio-visual tools, engaging books and interactive stimulating activities; we ready the leaders of tomorrow to take to the world, in the most graceful and creative way.</h4>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>

                                <div class="dt-sc-hr-very-small"></div>

                            
               <!--dt-sc-one-half ends-->
                        
                  
                    </div>