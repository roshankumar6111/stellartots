  <div class="container">
                        <!--dt-sc-one-half starts-->
                            <h2>Facilities</h2>
                            <!--dt-sc-one-half starts-->

                                
                                <div class="dt-sc-ico-content type2">
                                    <div class="icon"> 
                                        <span> > </span> 
                                    </div>
                                    
                                    <h4 style="color:white;">100% English literacy ; Fully air-conditioned classrooms ; Concept based puzzles ; Home cooked meals ; Equipped Children’s Library ; Audio- Visual Interaction ; Stage exposure ; Projector Movie Screening ; Monthly Health Check- ups ;  Story Telling sessions ; Puppet theatre ; Picnic outings ; Birthday celebrations with cake ; Digital Presence of classroom activities ; WhatsApp connectivity ; Festival celebrations with relevant goodie bags ; Ample play area with Ball pool.</h4>
                                </div>
                                <div class="dt-sc-hr-very-small"></div>

                                <div class="dt-sc-hr-very-small"></div>

                            
               <!--dt-sc-one-half ends-->
                        
                  
                    </div>