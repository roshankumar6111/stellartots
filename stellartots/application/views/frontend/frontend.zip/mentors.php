<div class="container">
    <h2>Our Mentored</h2>
                    <div class="column dt-sc-one-fourth first ">
                        <div class="dt-sc-team">	
                            <div class="image">
<!--                                <img class="item-mask" src="" alt="" title="">-->
                                <img src="<?php base_url();?>assets/images/teacher2.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4 style="color:white;"> Jack Daniels </h4>
                                <h4 style="color:white;"> Senior Supervisor </h4>
                                <p style="color:white;"> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                       <div class="column dt-sc-one-fourth first ">
                        <div class="dt-sc-team">	
                            <div class="image">
<!--                                <img class="item-mask" src="<?php base_url();?>assets/images/teacher1.jpg" alt="" title="">-->
                                <img src="<?php base_url();?>assets/images/teacher1.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4 style="color:white;"> Jack Daniels </h4>
                                <h4 style="color:white;"> Senior Supervisor </h4>
                                <p style="color:white;"> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                      <div class="column dt-sc-one-fourth first ">
                        <div class="dt-sc-team">	
                            <div class="image">
<!--                                <img class="item-mask" src="images/mask.png" alt="" title="">-->
                                <img src="<?php base_url();?>assets/images/teacher3.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4 style="color:white;"> Jack Daniels </h4>
                                <h4 style="color:white;"> Senior Supervisor </h4>
                                <p style="color:white;"> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
                       <div class="column dt-sc-one-fourth first ">
                        <div class="dt-sc-team">	
                            <div class="image">
<!--                                <img class="item-mask" src="images/mask.png" alt="" title="">-->
                                <img src="<?php base_url();?>assets/images/teacher4.jpg" alt="" title="">
                                <div class="dt-sc-image-overlay">
                                	<a href="#" class="link"><span class="fa fa-link"></span></a>
                                    <a href="#" class="zoom"><span class="fa fa-search"></span></a>
                                </div>
                            </div>
                            <div class="team-details">
                                <h4 style="color:white;"> Jack Daniels </h4>
                                <h4 style="color:white;"> Senior Supervisor </h4>
                                <p style="color:white;"> Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus. </p>
                            </div>
                        </div>
                    </div>
    </div>